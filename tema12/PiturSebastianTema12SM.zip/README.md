### PIȚUR SEBASTIAN 344C1
## Algoritmul lui PRIM
#### Implementarea seriala este inspirata din cea de pe linkul:
- https://www.geeksforgeeks.org/prims-minimum-spanning-tree-mst-greedy-algo-5/
#### Toate variantele au citirea facuta de un singur thread si un mod de a paraleliza gasirea muchiei minime in functie de biblioteca de thread-uri folosita
#### De asemenea in afara de varianta cu mpi, toate celelalte programe paralelizeaza si atribuirea de noi chei.
#### Rularea este de tipul ./program fisier_intrare (ex. input4.txt, input8.txt etc.)

